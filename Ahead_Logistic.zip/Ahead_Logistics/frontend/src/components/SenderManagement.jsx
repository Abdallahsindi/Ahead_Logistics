import { useEffect, useState } from "react";
import { createSender, fetchGovernorates, fetchSenders } from "../services/api";

function SenderManagement({ onActivity }) {
  const [senders, setSenders] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [governorates, setGovernorates] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState({
    full_name: "",
    area: "",
    pickup_shift: "",
    phone: "",
  });

  useEffect(() => {
    async function load() {
      try {
        setLoading(true);
        setError("");
        const [data, governoratesData] = await Promise.all([fetchSenders(), fetchGovernorates()]);
        setSenders(data);
        setGovernorates(governoratesData);
      } catch (err) {
        setError(err.message || "Unable to load senders");
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  async function handleCreateSender() {
    try {
      const created = await createSender(form);
      setSenders((prev) => [created, ...prev]);
      setModalOpen(false);
      setForm({ full_name: "", area: "", pickup_shift: "", phone: "" });
      onActivity({ text: `Sender ${created.full_name} added`, time: new Date().toLocaleTimeString("en-GB") });
    } catch (err) {
      setError(err.message || "Unable to create sender");
    }
  }

  return (
    <main className="main-view">
      <div className="main-header">
        <div>
          <h1>Factories / Warehouses</h1>
          <p>{senders.length} factories registered</p>
        </div>
        <button type="button" className="primary-btn" onClick={() => setModalOpen(true)}>
          Add New Factory
        </button>
      </div>
      {loading && <p className="muted">Loading senders...</p>}
      {error && <p className="error">{error}</p>}
      {!loading && !error && (
        <div className="card">
           <div className="card-head"><h2>Factories / Warehouses</h2></div>
          <div className="table-wrap">
            <table className="table">
              <thead>
                <tr>
                   <th>Factory Name</th>
                  <th>Area</th>
                   <th>Pickup Shift</th>
                  <th>Phone</th>
                </tr>
              </thead>
              <tbody>
                {senders.map((s) => (
                  <tr key={s.id}>
                    <td>{s.full_name}</td>
                    <td>{s.area}</td>
                    <td>{s.pickup_shift}</td>
                    <td>{s.phone}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      {modalOpen && (
        <div className="modal-backdrop">
          <div className="modal-card">
            <h3>Add New Factory / Warehouse</h3>
            <input className="modal-input" placeholder="Factory / Warehouse Name" value={form.full_name} onChange={(e) => setForm((p) => ({ ...p, full_name: e.target.value }))} />
            <select className="modal-input" value={form.area} onChange={(e) => setForm((p) => ({ ...p, area: e.target.value }))}>
              <option value="" disabled>Select Governorate</option>
              {governorates.map((g) => <option key={g} value={g}>{g}</option>)}
            </select>
            <select className="modal-input" value={form.pickup_shift} onChange={(e) => setForm((p) => ({ ...p, pickup_shift: e.target.value }))}>
              <option value="" disabled>Select Pickup Shift</option>
              <option value="morning">morning</option>
              <option value="evening">evening</option>
              <option value="overnight">overnight</option>
            </select>
            <input className="modal-input" placeholder="Phone Number" value={form.phone} onChange={(e) => setForm((p) => ({ ...p, phone: e.target.value }))} />
            <div className="modal-actions">
              <button type="button" className="small-btn" onClick={handleCreateSender}>Create</button>
              <button type="button" className="small-btn" onClick={() => setModalOpen(false)}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}

export default SenderManagement;
