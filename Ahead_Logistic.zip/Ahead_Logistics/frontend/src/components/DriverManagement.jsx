import { useEffect, useState } from "react";
import { createDriver, fetchDrivers, fetchGovernorates } from "../services/api";

function DriverManagement({ onActivity }) {
  const [drivers, setDrivers] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [governorates, setGovernorates] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState({
    full_name: "",
    phone: "",
    license_number: "",
    vehicle_type: "",
    shift: "",
    work_area: "",
    status: "available",
  });

  useEffect(() => {
    async function load() {
      try {
        setLoading(true);
        setError("");
        const [data, governoratesData] = await Promise.all([fetchDrivers(), fetchGovernorates()]);
        setDrivers(data);
        setGovernorates(governoratesData);
      } catch (err) {
        setError(err.message || "Unable to load drivers");
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  async function handleCreateDriver() {
    try {
      const created = await createDriver(form);
      setDrivers((prev) => [created, ...prev]);
      setModalOpen(false);
      setForm({
        full_name: "",
        phone: "",
        license_number: "",
        vehicle_type: "",
        shift: "",
        work_area: "",
        status: "available",
      });
      onActivity({
        text: `Driver ${created.full_name} added`,
        time: new Date().toLocaleTimeString("en-GB"),
      });
    } catch (err) {
      setError(err.message || "Unable to create driver");
    }
  }

  return (
    <main className="main-view">
      <div className="main-header">
        <div>
          <h1>Driver Management</h1>
          <p>{drivers.length} drivers registered</p>
        </div>
        <button
          type="button"
          className="primary-btn"
          onClick={() => setModalOpen(true)}
        >
          Add New Driver
        </button>
      </div>
      {loading && <p className="muted">Loading drivers...</p>}
      {error && <p className="error">{error}</p>}
      {!loading && !error && (
        <div className="card">
          <div className="card-head">
            <h2>Drivers</h2>
          </div>
          <div className="table-wrap">
            <table className="table">
              <thead>
                <tr>
                  <th>Full Name</th>
                  <th>Phone</th>
                  <th>License</th>
                  <th>Vehicle</th>
                  <th>Shift</th>
                  <th>Area</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {drivers.map((d) => (
                  <tr key={d.id}>
                    <td>{d.full_name}</td>
                    <td>{d.phone}</td>
                    <td>{d.license_number}</td>
                    <td>{d.vehicle_type || "-"}</td>
                    <td>{d.shift || "-"}</td>
                    <td>{d.work_area || "-"}</td>
                    <td className="status-cell">
                      <span className={d.status === "off_duty" ? "tag tag-coral" : "tag tag-yellow"}>
                        {d.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      {modalOpen && (
        <div className="modal-backdrop">
          <div className="modal-card">
            <h3>Add Driver</h3>
            <input className="modal-input" placeholder="Driver Name" value={form.full_name} onChange={(e) => setForm((p) => ({ ...p, full_name: e.target.value }))} />
            <input className="modal-input" placeholder="Phone" value={form.phone} onChange={(e) => setForm((p) => ({ ...p, phone: e.target.value }))} />
            <input className="modal-input" placeholder="License Number" value={form.license_number} onChange={(e) => setForm((p) => ({ ...p, license_number: e.target.value }))} />
            <select className="modal-input" value={form.vehicle_type} onChange={(e) => setForm((p) => ({ ...p, vehicle_type: e.target.value }))}>
              <option value="" disabled>Select Vehicle Type</option>
              <option value="van">Van</option>
              <option value="jumbo">Jumbo</option>
              <option value="trila">Trila</option>
            </select>
            <select className="modal-input" value={form.shift} onChange={(e) => setForm((p) => ({ ...p, shift: e.target.value }))}>
              <option value="" disabled>Select Shift</option>
              <option value="morning">Morning</option>
              <option value="evening">Evening</option>
              <option value="overnight">Overnight</option>
            </select>
            <select className="modal-input" value={form.work_area} onChange={(e) => setForm((p) => ({ ...p, work_area: e.target.value }))}>
              <option value="" disabled>Select Governorate</option>
              {governorates.map((g) => <option key={g} value={g}>{g}</option>)}
            </select>
            <div className="modal-actions">
              <button type="button" className="small-btn" onClick={handleCreateDriver}>Create</button>
              <button type="button" className="small-btn" onClick={() => setModalOpen(false)}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}

export default DriverManagement;
