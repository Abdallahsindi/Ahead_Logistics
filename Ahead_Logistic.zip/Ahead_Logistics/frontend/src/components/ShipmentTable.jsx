import { fetchShipmentById, updateShipmentStatus } from "../services/api";
import { useState } from "react";

function ShipmentTable({ shipments, onActivity, onShipmentUpdated, onViewAll, limit }) {
  const [statusModal, setStatusModal] = useState({ open: false, shipmentId: null, value: "created" });
  const [detailsModal, setDetailsModal] = useState({ open: false, shipment: null });
  const [trackingQuery, setTrackingQuery] = useState("");
  const statusClassByValue = (status) => {
    const value = String(status || "").toLowerCase();
    if (value === "delivered") return "tag tag-delivered";
    if (value === "in_transit" || value === "out_for_delivery") return "tag tag-in_transit";
    if (value === "delayed" || value === "cancelled") return "tag tag-coral";
    return "tag tag-assigned";
  };

  const handleOptions = async (id) => {
    try {
      const details = await fetchShipmentById(id);
      setDetailsModal({ open: true, shipment: details });
      onActivity({
        text: `Viewed details for ${details.tracking_number}`,
        time: new Date().toLocaleTimeString("en-GB"),
      });
    } catch (err) {
      onActivity({
        text: `Failed to view shipment ${id}: ${err.message}`,
        time: new Date().toLocaleTimeString("en-GB"),
      });
    }
  };

  async function handleStatusSave() {
    try {
      const updated = await updateShipmentStatus(statusModal.shipmentId, statusModal.value);
      if (onShipmentUpdated) {
        onShipmentUpdated(updated);
      }
      onActivity({
        text: `Shipment ${updated.tracking_number} status changed to ${updated.shipment_status}`,
        time: new Date().toLocaleTimeString("en-GB"),
      });
      setStatusModal({ open: false, shipmentId: null, value: "created" });
    } catch (err) {
      onActivity({
        text: `Status update failed: ${err.message}`,
        time: new Date().toLocaleTimeString("en-GB"),
      });
    }
  }

  const filteredShipments = shipments.filter((s) =>
    String(s.tracking_number || "").toLowerCase().includes(trackingQuery.trim().toLowerCase())
  );

  return (
    <div className="card">
      <div className="card-head">
        <h2>Recent Shipments</h2>
        <button type="button" className="view-all-btn" onClick={onViewAll}>View All</button>
      </div>
      <div className="table-toolbar">
        <input
          className="table-search"
          placeholder="Track shipment by ID..."
          value={trackingQuery}
          onChange={(e) => setTrackingQuery(e.target.value)}
        />
      </div>
      <div className="table-wrap">
        <table className="table">
          <thead>
            <tr>
              <th>Tracking #</th>
              <th>Receiver</th>
              <th>Destination</th>
              <th>Date</th>
              <th>Amount</th>
              <th>Status</th>
              <th>Options</th>
            </tr>
          </thead>
          <tbody>
            {(typeof limit === "number" ? filteredShipments.slice(0, limit) : filteredShipments).map((s) => (
              <tr key={s.id}>
                <td>{s.tracking_number}</td>
                <td>{s.receiver_name}</td>
                <td>{s.destination_address}</td>
                <td>{new Date(s.created_at).toLocaleDateString("en-GB")}</td>
                <td>
                  {new Intl.NumberFormat("en-EG", {
                    style: "currency",
                    currency: "EGP",
                    maximumFractionDigits: 0,
                  }).format(Number(s.price_egp || 0))}
                </td>
                <td className="status-cell">
                  <span className={statusClassByValue(s.shipment_status)}>
                    {s.shipment_status}
                  </span>
                </td>
                <td>
                  <div className="options-row">
                    <button type="button" className="small-btn" onClick={() => handleOptions(s.id)}>
                      Details
                    </button>
                    <button
                      type="button"
                      className="small-btn"
                      onClick={() => setStatusModal({ open: true, shipmentId: s.id, value: s.shipment_status })}
                    >
                      Change Status
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {statusModal.open && (
        <div className="modal-backdrop">
          <div className="modal-card">
            <h3>Change Shipment Status</h3>
            <select
              className="modal-input"
              value={statusModal.value}
              onChange={(e) => setStatusModal((prev) => ({ ...prev, value: e.target.value }))}
            >
              <option value="created">created</option>
              <option value="assigned">assigned</option>
              <option value="in_transit">in_transit</option>
              <option value="out_for_delivery">out_for_delivery</option>
              <option value="delivered">delivered</option>
              <option value="delayed">delayed</option>
              <option value="cancelled">cancelled</option>
            </select>
            <div className="modal-actions">
              <button type="button" className="small-btn" onClick={handleStatusSave}>
                Save
              </button>
              <button
                type="button"
                className="small-btn"
                onClick={() => setStatusModal({ open: false, shipmentId: null, value: "created" })}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
      {detailsModal.open && detailsModal.shipment && (
        <div className="modal-backdrop">
          <div className="modal-card">
            <h3>Shipment Details</h3>
            <div className="details-grid">
              <p><strong>Tracking ID:</strong> {detailsModal.shipment.tracking_number}</p>
              <p><strong>Status:</strong> {detailsModal.shipment.shipment_status}</p>
              <p><strong>Assigned Driver:</strong> {detailsModal.shipment.driver_name || "-"}</p>
              <p><strong>Sender:</strong> {detailsModal.shipment.sender_name || "-"}</p>
              <p><strong>Receiver:</strong> {detailsModal.shipment.receiver_full_name || detailsModal.shipment.receiver_name || "-"}</p>
              <p><strong>Picked Up From:</strong> {detailsModal.shipment.source_warehouse_name || "-"}</p>
              <p><strong>Current Location:</strong> {detailsModal.shipment.current_location || "-"}</p>
              <p><strong>Destination:</strong> {detailsModal.shipment.destination_address || "-"}</p>
              <p><strong>Pickup Date:</strong> {detailsModal.shipment.created_at ? new Date(detailsModal.shipment.created_at).toLocaleString("en-GB") : "-"}</p>
              <p><strong>Expected Delivery:</strong> {detailsModal.shipment.expected_delivery_date ? new Date(detailsModal.shipment.expected_delivery_date).toLocaleDateString("en-GB") : "-"}</p>
              <p><strong>Weight:</strong> {detailsModal.shipment.weight_kg} KG</p>
              <p><strong>Delivery Fee:</strong> {new Intl.NumberFormat("en-EG", { style: "currency", currency: "EGP", maximumFractionDigits: 0 }).format(Number(detailsModal.shipment.price_egp || 0))}</p>
            </div>
            <div className="modal-actions">
              <button type="button" className="small-btn" onClick={() => setDetailsModal({ open: false, shipment: null })}>
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default ShipmentTable;
