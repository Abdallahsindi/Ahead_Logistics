import { useEffect, useState } from "react";
import { fetchRevenueSummary } from "../services/api";

function AnalyticsView() {
  const [summary, setSummary] = useState({ total_egp: 0, today_egp: 0, week_egp: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    async function load() {
      try {
        setLoading(true);
        setError("");
        const data = await fetchRevenueSummary();
        setSummary(data);
      } catch (err) {
        setError(err.message || "Unable to load analytics");
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  return (
    <main className="main-view">
      <div className="main-header">
        <div>
          <h1>Analytics</h1>
          <p>Live revenue KPIs (EGP)</p>
        </div>
      </div>
      {loading && <p className="muted">Loading analytics...</p>}
      {error && <p className="error">{error}</p>}
      {!loading && !error && (
        <div className="stats-grid">
          <div className="card stat-card">
            <p>Today</p>
            <h3>{new Intl.NumberFormat("en-EG", { style: "currency", currency: "EGP", maximumFractionDigits: 0 }).format(Number(summary.today_egp || 0))}</h3>
          </div>
          <div className="card stat-card">
            <p>This Week</p>
            <h3>{new Intl.NumberFormat("en-EG", { style: "currency", currency: "EGP", maximumFractionDigits: 0 }).format(Number(summary.week_egp || 0))}</h3>
          </div>
          <div className="card stat-card">
            <p>This Month</p>
            <h3>{new Intl.NumberFormat("en-EG", { style: "currency", currency: "EGP", maximumFractionDigits: 0 }).format(Number(summary.total_egp || 0))}</h3>
          </div>
        </div>
      )}
    </main>
  );
}

export default AnalyticsView;
