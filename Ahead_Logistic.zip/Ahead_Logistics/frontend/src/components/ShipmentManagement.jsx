import { useEffect, useState } from "react";
import { createShipment, fetchDistanceEstimate, fetchDrivers, fetchReceivers, fetchSenders, fetchShipments } from "../services/api";
import ShipmentTable from "./ShipmentTable";

function ShipmentManagement({ onActivity }) {
  const [shipments, setShipments] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [senders, setSenders] = useState([]);
  const [receivers, setReceivers] = useState([]);
  const [drivers, setDrivers] = useState([]);
  const [shipmentForm, setShipmentForm] = useState({
    tracking_number: "",
    source_warehouse_id: "",
    sender_id: "",
    receiver_id: "",
    driver_id: "",
    destination_address: "",
    receiver_phone: "",
    weight_kg: "",
    distance_km: "",
    current_location: "",
    expected_delivery_date: "",
    shipment_status: "created",
  });

  useEffect(() => {
    async function load() {
      try {
        setLoading(true);
        setError("");
        const [shipmentData, senderData, receiverData, availableDrivers] = await Promise.all([
          fetchShipments(),
          fetchSenders(),
          fetchReceivers(),
          fetchDrivers("available"),
        ]);
        setShipments(shipmentData);
        setSenders(senderData);
        setReceivers(receiverData);
        setDrivers(availableDrivers);
      } catch (err) {
        setError(err.message || "Unable to load shipments");
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  useEffect(() => {
    async function resolveDistance() {
      try {
        if (!shipmentForm.sender_id || !shipmentForm.receiver_id) {
          setShipmentForm((prev) => ({ ...prev, distance_km: "", destination_address: "" }));
          return;
        }

        const [distanceData, selectedReceiver] = await Promise.all([
          fetchDistanceEstimate(shipmentForm.sender_id, shipmentForm.receiver_id),
          Promise.resolve(receivers.find((r) => String(r.id) === String(shipmentForm.receiver_id))),
        ]);
        setShipmentForm((prev) => ({
          ...prev,
          distance_km: String(distanceData.distance_km || ""),
          destination_address: selectedReceiver ? selectedReceiver.area : prev.destination_address,
          receiver_phone: selectedReceiver?.phone || prev.receiver_phone,
        }));
      } catch (err) {
        setError(err.message || "Unable to estimate distance");
      }
    }

    resolveDistance();
  }, [shipmentForm.sender_id, shipmentForm.receiver_id, receivers]);

  async function handleCreateShipment() {
    try {
      setError("");
      const created = await createShipment({
        tracking_number: shipmentForm.tracking_number || `EG-${Date.now()}`,
        source_warehouse_id: Number(shipmentForm.source_warehouse_id),
        sender_id: Number(shipmentForm.sender_id),
        receiver_id: Number(shipmentForm.receiver_id),
        driver_id: Number(shipmentForm.driver_id),
        destination_address: shipmentForm.destination_address,
        receiver_phone: shipmentForm.receiver_phone,
        weight_kg: Number(shipmentForm.weight_kg),
        current_location: shipmentForm.current_location,
        expected_delivery_date: shipmentForm.expected_delivery_date,
        shipment_status: shipmentForm.shipment_status,
      });
      setShipments((prev) => [created, ...prev]);
      setCreateModalOpen(false);
      setShipmentForm({
        tracking_number: "",
        source_warehouse_id: "",
        sender_id: "",
        receiver_id: "",
        driver_id: "",
        destination_address: "",
        receiver_phone: "",
        weight_kg: "",
        distance_km: "",
        current_location: "",
        expected_delivery_date: "",
        shipment_status: "created",
      });
      onActivity({
        text: `New shipment ${created.tracking_number} created`,
        time: new Date().toLocaleTimeString("en-GB"),
      });
    } catch (err) {
      setError(err.message || "Failed to create shipment");
    }
  }

  return (
    <main className="main-view">
      <div className="main-header">
        <div>
          <h1>Shipment Management</h1>
          <p>{shipments.length} packages total</p>
        </div>
        <button
          type="button"
          className="primary-btn"
          onClick={() => setCreateModalOpen(true)}
        >
          Add New Package
        </button>
      </div>
      {loading && <p className="muted">Loading shipments...</p>}
      {error && <p className="error">{error}</p>}
      {!loading && !error && (
        <ShipmentTable
          shipments={shipments}
          onActivity={onActivity}
          onViewAll={() => {}}
          onShipmentUpdated={(updated) =>
            setShipments((prev) => prev.map((item) => (item.id === updated.id ? { ...item, ...updated } : item))
            )
          }
        />
      )}
      {createModalOpen && (
        <div className="modal-backdrop">
          <div className="modal-card">
            <h3>New Shipment</h3>
            <input
              className="modal-input"
              placeholder="Tracking Number (optional)"
              value={shipmentForm.tracking_number}
              onChange={(e) => setShipmentForm((p) => ({ ...p, tracking_number: e.target.value }))}
            />
            <select
              className="modal-input"
              value={shipmentForm.source_warehouse_id}
              onChange={(e) => setShipmentForm((p) => ({ ...p, source_warehouse_id: e.target.value }))}
            >
              <option value="" disabled>Select Source Warehouse</option>
              <option value="1">Cairo Central Hub</option>
              <option value="2">Giza West Hub</option>
              <option value="3">Alexandria Port Hub</option>
              <option value="4">Monufia Delta Hub</option>
              <option value="5">Dakahlia Nile Hub</option>
            </select>
            <select
              className="modal-input"
              value={shipmentForm.sender_id}
              onChange={(e) => setShipmentForm((p) => ({ ...p, sender_id: e.target.value }))}
            >
              <option value="" disabled>Select sender</option>
              {senders.map((s) => (
                <option key={s.id} value={s.id}>{s.full_name} - {s.area}</option>
              ))}
            </select>
            <select
              className="modal-input"
              value={shipmentForm.receiver_id}
              onChange={(e) => setShipmentForm((p) => ({ ...p, receiver_id: e.target.value }))}
            >
              <option value="" disabled>Select receiver</option>
              {receivers.map((r) => (
                <option key={r.id} value={r.id}>{r.full_name} - {r.area}</option>
              ))}
            </select>
            <select
              className="modal-input"
              value={shipmentForm.driver_id}
              onChange={(e) => setShipmentForm((p) => ({ ...p, driver_id: e.target.value }))}
            >
              <option value="" disabled>Select available driver</option>
              {drivers.map((d) => (
                <option key={d.id} value={d.id}>{d.full_name} - {d.work_area}</option>
              ))}
            </select>
            <input className="modal-input" readOnly value={shipmentForm.destination_address} placeholder="Destination governorate (auto)" />
            <input
              className="modal-input"
              placeholder="Receiver Phone"
              value={shipmentForm.receiver_phone}
              onChange={(e) => setShipmentForm((p) => ({ ...p, receiver_phone: e.target.value }))}
            />
            <input
              className="modal-input"
              placeholder="Weight KG"
              value={shipmentForm.weight_kg}
              onChange={(e) => setShipmentForm((p) => ({ ...p, weight_kg: e.target.value }))}
            />
            <div className="modal-readonly-line">
              <span>Distance (Auto)</span>
              <strong>{shipmentForm.distance_km ? `${shipmentForm.distance_km} KM` : "-"}</strong>
            </div>
            <div className="modal-readonly-line">
              <span>Pricing Rule</span>
              <strong>70 + (3 x KM) + (1 x KG) EGP</strong>
            </div>
            <input
              className="modal-input"
              placeholder="Current Location"
              value={shipmentForm.current_location}
              onChange={(e) => setShipmentForm((p) => ({ ...p, current_location: e.target.value }))}
            />
            <input
              className="modal-input"
              type="date"
              value={shipmentForm.expected_delivery_date}
              onChange={(e) => setShipmentForm((p) => ({ ...p, expected_delivery_date: e.target.value }))}
            />
            <div className="modal-actions">
              <button type="button" className="small-btn" onClick={handleCreateShipment}>
                Create
              </button>
              <button type="button" className="small-btn" onClick={() => setCreateModalOpen(false)}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}

export default ShipmentManagement;
