const navItems = [
  { label: "Dashboard", view: "dashboard" },
  { label: "Shipments", view: "shipments" },
  { label: "Factories", view: "senders" },
  { label: "Retail Shops", view: "receivers" },
  { label: "Drivers", view: "drivers" },
  { label: "Routes", view: "routes" },
];

function Sidebar({ activeView, onNavigate }) {
  return (
    <aside className="sidebar">
      <div>
        <div className="sidebar-header">
          <h1>
            Ahead<span>.</span>
          </h1>
          <p>Egypt Logistics Platform</p>
        </div>

        <nav className="sidebar-nav">
          {navItems.map((item) => (
            <button
              key={item.view}
              type="button"
              onClick={() => onNavigate(item.view)}
              className={`sidebar-nav-btn ${activeView === item.view ? "active" : ""}`}
            >
              {item.label}
            </button>
          ))}
        </nav>
      </div>
    </aside>
  );
}

export default Sidebar;
