function ActivityPanel({ items }) {
  const dotClass = (text) => {
    const value = String(text || "").toLowerCase();
    if (value.includes("failed") || value.includes("delayed")) return "coral";
    if (value.includes("delivered") || value.includes("completed")) return "green";
    return "yellow";
  };

  return (
    <aside className="activity-panel">
      <div className="panel-head">
        <h2>Activity</h2>
      </div>
      <div className="activity-content">
        {items.map((item) => (
          <div key={item.id} className="activity-row">
            <span className={`activity-dot ${dotClass(item.text)}`} />
            <div>
              <p>{item.text}</p>
              <p className="muted">{item.time}</p>
            </div>
          </div>
        ))}
        {items.length === 0 && <p className="muted">No activity yet.</p>}
      </div>
    </aside>
  );
}

export default ActivityPanel;
