import shipmentsIcon from "../../../icons/shipments.png";
import availableDriversIcon from "../../../icons/avilabledrivers.png";
import inTransitIcon from "../../../icons/tranist.png";
import delayedIcon from "../../../icons/delayed.png";

const iconByTitle = {
  "Total Shipments": shipmentsIcon,
  "Available Drivers": availableDriversIcon,
  "In Transit": inTransitIcon,
  Delayed: delayedIcon,
};

function StatCard({ title, value }) {
  const iconPath = iconByTitle[title];
  return (
    <div className="card stat-card">
      <div className="stat-top">
        <p>{title}</p>
        <span className="stat-icon">
          {iconPath ? <img src={iconPath} alt={title} /> : null}
        </span>
      </div>
      <h3>{value}</h3>
    </div>
  );
}

export default StatCard;
