import { useEffect, useState } from "react";
import { createReceiver, fetchGovernorates, fetchReceivers } from "../services/api";

function ReceiverManagement({ onActivity }) {
  const [receivers, setReceivers] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [governorates, setGovernorates] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState({
    full_name: "",
    area: "",
    receive_shift: "",
    phone: "",
  });

  useEffect(() => {
    async function load() {
      try {
        setLoading(true);
        setError("");
        const [data, governoratesData] = await Promise.all([fetchReceivers(), fetchGovernorates()]);
        setReceivers(data);
        setGovernorates(governoratesData);
      } catch (err) {
        setError(err.message || "Unable to load receivers");
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  async function handleCreateReceiver() {
    try {
      const created = await createReceiver(form);
      setReceivers((prev) => [created, ...prev]);
      setModalOpen(false);
      setForm({ full_name: "", area: "", receive_shift: "", phone: "" });
      onActivity({ text: `Receiver ${created.full_name} added`, time: new Date().toLocaleTimeString("en-GB") });
    } catch (err) {
      setError(err.message || "Unable to create receiver");
    }
  }

  return (
    <main className="main-view">
      <div className="main-header">
        <div>
          <h1>Retail Shops / Outlets</h1>
          <p>{receivers.length} shops registered</p>
        </div>
        <button type="button" className="primary-btn" onClick={() => setModalOpen(true)}>
          Add New Shop
        </button>
      </div>
      {loading && <p className="muted">Loading receivers...</p>}
      {error && <p className="error">{error}</p>}
      {!loading && !error && (
        <div className="card">
           <div className="card-head"><h2>Retail Shops / Outlets</h2></div>
          <div className="table-wrap">
            <table className="table">
              <thead>
                <tr>
                   <th>Shop Name</th>
                  <th>Area</th>
                  <th>Receive Shift</th>
                  <th>Phone</th>
                </tr>
              </thead>
              <tbody>
                {receivers.map((r) => (
                  <tr key={r.id}>
                    <td>{r.full_name}</td>
                    <td>{r.area}</td>
                    <td>{r.receive_shift}</td>
                    <td>{r.phone}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      {modalOpen && (
        <div className="modal-backdrop">
          <div className="modal-card">
            <h3>Add New Retail Shop / Outlet</h3>
            <input className="modal-input" placeholder="Retail Shop / Outlet Name" value={form.full_name} onChange={(e) => setForm((p) => ({ ...p, full_name: e.target.value }))} />
            <select className="modal-input" value={form.area} onChange={(e) => setForm((p) => ({ ...p, area: e.target.value }))}>
              <option value="" disabled>Select Governorate</option>
              {governorates.map((g) => <option key={g} value={g}>{g}</option>)}
            </select>
            <input className="modal-input" placeholder="Phone Number" value={form.phone} onChange={(e) => setForm((p) => ({ ...p, phone: e.target.value }))} />
            <select className="modal-input" value={form.receive_shift} onChange={(e) => setForm((p) => ({ ...p, receive_shift: e.target.value }))}>
              <option value="" disabled>Select Receive Shift</option>
              <option value="morning">morning</option>
              <option value="evening">evening</option>
              <option value="overnight">overnight</option>
            </select>
            <div className="modal-actions">
              <button type="button" className="small-btn" onClick={handleCreateReceiver}>Create</button>
              <button type="button" className="small-btn" onClick={() => setModalOpen(false)}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}

export default ReceiverManagement;
