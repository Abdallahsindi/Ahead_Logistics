import { useEffect, useMemo, useState } from "react";
import { fetchDashboardAnalytics, fetchRevenueSummary, fetchRoutesOverview, fetchShipments } from "../services/api";
import ShipmentTable from "./ShipmentTable";
import StatCard from "./StatCard";

function Dashboard({ onActivity, onNavigate }) {
  const [analytics, setAnalytics] = useState({});
  const [shipments, setShipments] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [routes, setRoutes] = useState([]);
  const [revenueSummary, setRevenueSummary] = useState({ total_egp: 0, today_egp: 0, week_egp: 0 });

  useEffect(() => {
    async function load() {
      try {
        setLoading(true);
        setError("");
        const [a, s, r, rev] = await Promise.all([
          fetchDashboardAnalytics(),
          fetchShipments(),
          fetchRoutesOverview("month"),
          fetchRevenueSummary(),
        ]);
        setAnalytics(a);
        setShipments(s);
        setRoutes(r);
        setRevenueSummary(rev);
      } catch (err) {
        setError(err.message || "Failed to load dashboard");
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  const revenue = useMemo(
    () => shipments.reduce((sum, s) => sum + Number(s.price_egp || Number(s.weight_kg || 0) * Number(s.distance_km || 0)), 0),
    [shipments]
  );

  function handleShipmentUpdated(updatedShipment) {
    setShipments((prev) =>
      prev.map((item) => (item.id === updatedShipment.id ? { ...item, ...updatedShipment } : item))
    );
  }

  return (
    <main className="main-view">
      <div className="main-header">
        <div>
          <h1>Dashboard</h1>
          <p>Egypt logistics live overview</p>
        </div>
        <button
          type="button"
          className="primary-btn"
          onClick={() => onNavigate("shipments")}
        >
          + New Shipment
        </button>
      </div>

      {error && <p className="error">{error}</p>}
      {loading && <p className="muted">Loading dashboard data...</p>}

      {!loading && (
        <>
          <div className="stats-grid">
            <StatCard title="Total Shipments" value={analytics.total_shipments || 0} />
            <StatCard title="Available Drivers" value={analytics.available_drivers || 0} />
            <StatCard title="In Transit" value={analytics.active_assignments || 0} />
            <StatCard title="Delayed" value={analytics.delayed_events || 0} />
          </div>

          <ShipmentTable
            shipments={shipments}
            onActivity={onActivity}
            onShipmentUpdated={handleShipmentUpdated}
            onViewAll={() => onNavigate("shipments")}
            limit={10}
          />

          <div className="bottom-grid">
            <div className="card panel-pad">
              <h3>Top Routes</h3>
              {(() => {
                const maxCount = Math.max(1, ...routes.slice(0, 3).map((r) => Number(r.shipments_count || 0)));
                return routes.slice(0, 3).map((route, idx) => (
                  <div key={`${route.destination_address}-${idx}`}>
                    <div className="route-row">
                      <span>{route.destination_address}</span>
                      <span>{route.shipments_count}</span>
                    </div>
                    <div className="route-bar">
                      <div style={{ width: `${Math.max(8, Math.round((Number(route.shipments_count || 0) / maxCount) * 100))}%` }} />
                    </div>
                  </div>
                ));
              })()}
            </div>

            <div className="card panel-pad">
              <h3>Revenue Summary</h3>
              <div className="sum-row"><span>Today</span><strong>{new Intl.NumberFormat("en-EG", { style: "currency", currency: "EGP", maximumFractionDigits: 0 }).format(Number(revenueSummary.today_egp || 0))}</strong></div>
              <div className="sum-row"><span>This Week</span><strong>{new Intl.NumberFormat("en-EG", { style: "currency", currency: "EGP", maximumFractionDigits: 0 }).format(Number(revenueSummary.week_egp || 0))}</strong></div>
              <div className="sum-row"><span>This Month</span><strong>{new Intl.NumberFormat("en-EG", { style: "currency", currency: "EGP", maximumFractionDigits: 0 }).format(Number(revenueSummary.total_egp || revenue))}</strong></div>
            </div>
          </div>
        </>
      )}
    </main>
  );
}

export default Dashboard;
