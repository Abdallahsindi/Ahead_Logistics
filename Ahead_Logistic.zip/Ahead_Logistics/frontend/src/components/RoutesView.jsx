import { useEffect, useState } from "react";
import { fetchRoutesOverview } from "../services/api";

function RoutesView({ onActivity }) {
  const [routes, setRoutes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [range, setRange] = useState("month");

  useEffect(() => {
    async function load() {
      try {
        setLoading(true);
        setError("");
        const data = await fetchRoutesOverview(range);
        setRoutes(data);
      } catch (err) {
        setError(err.message || "Unable to load routes");
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [range]);

  return (
    <main className="main-view">
      <div className="main-header">
        <div>
          <h1>Routes</h1>
          <p>Aggregated by destination</p>
        </div>
      </div>
      <div className="options-row" style={{ marginBottom: "12px" }}>
        <button type="button" className={`small-btn${range === "day" ? " active" : ""}`} onClick={() => setRange("day")}>Day</button>
        <button type="button" className={`small-btn${range === "week" ? " active" : ""}`} onClick={() => setRange("week")}>Week</button>
        <button type="button" className={`small-btn${range === "month" ? " active" : ""}`} onClick={() => setRange("month")}>Month</button>
      </div>
      {loading && <p className="muted">Loading routes...</p>}
      {error && <p className="error">{error}</p>}
      {!loading && !error && (
        <div className="card panel-pad">
          {routes.length === 0 && <p className="muted">No route data available.</p>}
          {(() => {
            const maxCount = Math.max(1, ...routes.map((r) => Number(r.shipments_count || 0)));
            return routes.map((r) => (
              <div key={r.destination_address}>
                <div className="route-row">
                  <span>{r.destination_address}</span>
                  <span>{r.shipments_count}</span>
                </div>
                <div className="route-bar">
                  <div style={{ width: `${Math.max(8, Math.round((Number(r.shipments_count || 0) / maxCount) * 100))}%` }} />
                </div>
              </div>
            ));
          })()}
        </div>
      )}
    </main>
  );
}

export default RoutesView;
