import { useState } from "react";
import Sidebar from "../components/Sidebar";
import Dashboard from "../components/Dashboard";
import ActivityPanel from "../components/ActivityPanel";
import DriverManagement from "../components/DriverManagement";
import ShipmentManagement from "../components/ShipmentManagement";
import RoutesView from "../components/RoutesView";
import AnalyticsView from "../components/AnalyticsView";
import SenderManagement from "../components/SenderManagement";
import ReceiverManagement from "../components/ReceiverManagement";

function Index() {
  const [activeView, setActiveView] = useState("dashboard");
  const [activityItems, setActivityItems] = useState([]);

  const onActivity = (item) => {
    setActivityItems((prev) => [{ id: `${Date.now()}-${Math.random()}`, ...item }, ...prev].slice(0, 20));
  };

  let renderMain = <Dashboard onActivity={onActivity} onNavigate={setActiveView} />;
  if (activeView === "drivers") {
    renderMain = <DriverManagement onActivity={onActivity} />;
  } else if (activeView === "senders") {
    renderMain = <SenderManagement onActivity={onActivity} />;
  } else if (activeView === "receivers") {
    renderMain = <ReceiverManagement onActivity={onActivity} />;
  } else if (activeView === "shipments") {
    renderMain = <ShipmentManagement onActivity={onActivity} />;
  } else if (activeView === "routes") {
    renderMain = <RoutesView onActivity={onActivity} />;
  } else if (activeView === "analytics") {
    renderMain = <AnalyticsView onActivity={onActivity} />;
  }

  return (
    <div className="app-shell">
      <Sidebar activeView={activeView} onNavigate={setActiveView} />
      {renderMain}
      <ActivityPanel items={activityItems} />
    </div>
  );
}

export default Index;
