import axios from "axios";

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:4000";

const api = axios.create({
  baseURL: `${API_BASE_URL}/api`,
});

function toServiceError(prefix, error) {
  const status = error?.response?.status;
  const message = error?.response?.data?.message || error.message;
  return new Error(`${prefix}${status ? ` (${status})` : ""}: ${message}`);
}

export async function fetchShipments() {
  try {
    const { data } = await api.get("/shipments");
    return data.data || data || [];
  } catch (error) {
    throw toServiceError("Shipment service error", error);
  }
}

export async function fetchDashboardAnalytics() {
  try {
    const { data } = await api.get("/analytics/dashboard");
    return data.data || data || {};
  } catch (error) {
    throw toServiceError("Analytics service error", error);
  }
}

export async function fetchShipmentById(id) {
  try {
    const { data } = await api.get(`/shipments/${id}`);
    return data.data || data;
  } catch (error) {
    throw toServiceError("Shipment details error", error);
  }
}

export async function fetchDrivers(status = "") {
  try {
    const { data } = await api.get("/drivers", { params: status ? { status } : {} });
    return data.data || data || [];
  } catch (error) {
    throw toServiceError("Drivers service error", error);
  }
}

export async function createShipment(payload) {
  try {
    const { data } = await api.post("/shipments", payload);
    return data.data || data;
  } catch (error) {
    throw toServiceError("Create shipment error", error);
  }
}

export async function fetchDistanceEstimate(senderId, receiverId) {
  try {
    const { data } = await api.get("/shipments/distance-estimate", {
      params: { sender_id: senderId, receiver_id: receiverId },
    });
    return data.data || data;
  } catch (error) {
    throw toServiceError("Distance estimate error", error);
  }
}

export async function updateShipmentStatus(id, shipment_status) {
  try {
    const { data } = await api.patch(`/shipments/${id}/status`, { shipment_status });
    return data.data || data;
  } catch (error) {
    throw toServiceError("Update shipment status error", error);
  }
}

export async function fetchRoutesOverview(range = "month") {
  try {
    const { data } = await api.get("/analytics/routes", { params: { range } });
    return data.data || data || [];
  } catch (error) {
    throw toServiceError("Routes analytics error", error);
  }
}

export async function fetchRevenueSummary() {
  try {
    const { data } = await api.get("/analytics/revenue");
    return data.data || data || {};
  } catch (error) {
    throw toServiceError("Revenue analytics error", error);
  }
}

export async function createDriver(payload) {
  try {
    const { data } = await api.post("/drivers", payload);
    return data.data || data;
  } catch (error) {
    throw toServiceError("Create driver error", error);
  }
}

export async function fetchSenders() {
  try {
    const { data } = await api.get("/senders");
    return data.data || data || [];
  } catch (error) {
    throw toServiceError("Senders service error", error);
  }
}

export async function fetchGovernorates() {
  try {
    const { data } = await api.get("/senders/governorates");
    return data.data || data || [];
  } catch (error) {
    throw toServiceError("Governorates service error", error);
  }
}

export async function createSender(payload) {
  try {
    const { data } = await api.post("/senders", payload);
    return data.data || data;
  } catch (error) {
    throw toServiceError("Create sender error", error);
  }
}

export async function fetchReceivers() {
  try {
    const { data } = await api.get("/receivers");
    return data.data || data || [];
  } catch (error) {
    throw toServiceError("Receivers service error", error);
  }
}

export async function createReceiver(payload) {
  try {
    const { data } = await api.post("/receivers", payload);
    return data.data || data;
  } catch (error) {
    throw toServiceError("Create receiver error", error);
  }
}
