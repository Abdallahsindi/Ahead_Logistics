-- ============================================================
-- Ahead Logistics - SQL Server (T-SQL) Version
-- Converted from Supabase/PostgreSQL
-- Pricing rule: total_price = 70 + (3 * distance_km) + (1 * weight_kg)
-- ============================================================

BEGIN TRANSACTION;

-- ============================================================
-- TABLES
-- ============================================================

-- Warehouses
CREATE TABLE warehouses (
    id              BIGINT IDENTITY(1,1) PRIMARY KEY,
    name            NVARCHAR(255)  NOT NULL UNIQUE,
    location        NVARCHAR(255)  NOT NULL,
    max_capacity_kg NUMERIC(12,2)  NOT NULL CHECK (max_capacity_kg > 0),
    current_load_kg NUMERIC(12,2)  NOT NULL DEFAULT 0 CHECK (current_load_kg >= 0),
    created_at      DATETIMEOFFSET NOT NULL DEFAULT SYSDATETIMEOFFSET(),
    CONSTRAINT chk_warehouses_load CHECK (current_load_kg <= max_capacity_kg)
);

-- Drivers
CREATE TABLE drivers (
    id                  BIGINT IDENTITY(1,1) PRIMARY KEY,
    full_name           NVARCHAR(255)  NOT NULL,
    license_number      NVARCHAR(100)  NOT NULL UNIQUE,
    phone               NVARCHAR(50)   NOT NULL UNIQUE,
    status              NVARCHAR(20)   NOT NULL DEFAULT 'available'
                            CHECK (status IN ('available', 'on_delivery', 'off_duty')),
    base_warehouse_id   BIGINT NULL REFERENCES warehouses(id) ON DELETE SET NULL,
    vehicle_type        NVARCHAR(10)   NULL CHECK (vehicle_type IN ('van', 'jumbo', 'trila')),
    shift               NVARCHAR(10)   NULL CHECK (shift IN ('morning', 'evening', 'overnight')),
    work_area           NVARCHAR(255)  NULL,
    created_at          DATETIMEOFFSET NOT NULL DEFAULT SYSDATETIMEOFFSET()
);

-- Senders
CREATE TABLE senders (
    id            BIGINT IDENTITY(1,1) PRIMARY KEY,
    full_name     NVARCHAR(255)  NOT NULL,
    area          NVARCHAR(255)  NOT NULL,
    pickup_shift  NVARCHAR(10)   NOT NULL CHECK (pickup_shift IN ('morning', 'evening', 'overnight')),
    phone         NVARCHAR(50)   NOT NULL,
    created_at    DATETIMEOFFSET NOT NULL DEFAULT SYSDATETIMEOFFSET()
);

-- Receivers
CREATE TABLE receivers (
    id             BIGINT IDENTITY(1,1) PRIMARY KEY,
    full_name      NVARCHAR(255)  NOT NULL,
    area           NVARCHAR(255)  NOT NULL,
    receive_shift  NVARCHAR(10)   NOT NULL CHECK (receive_shift IN ('morning', 'evening', 'overnight')),
    phone          NVARCHAR(50)   NOT NULL,
    created_at     DATETIMEOFFSET NOT NULL DEFAULT SYSDATETIMEOFFSET()
);

-- Shipments
CREATE TABLE shipments (
    id                      BIGINT IDENTITY(1,1) PRIMARY KEY,
    tracking_number         NVARCHAR(100)  NOT NULL UNIQUE,
    source_warehouse_id     BIGINT         NOT NULL REFERENCES warehouses(id) ON DELETE NO ACTION,
    sender_id               BIGINT         NULL REFERENCES senders(id) ON DELETE SET NULL,
    receiver_id             BIGINT         NULL REFERENCES receivers(id),
    driver_id               BIGINT         NULL REFERENCES drivers(id),
    destination_address     NVARCHAR(500)  NOT NULL,
    receiver_name           NVARCHAR(255)  NOT NULL,
    receiver_phone          NVARCHAR(50)   NOT NULL,
    weight_kg               NUMERIC(10,2)  NOT NULL CHECK (weight_kg > 0),
    distance_km             NUMERIC(10,2)  NOT NULL CHECK (distance_km > 0),
    price_egp               NUMERIC(10,2)  NOT NULL CHECK (price_egp > 0),
    current_location        NVARCHAR(500)  NULL,
    shipment_status         NVARCHAR(20)   NOT NULL DEFAULT 'created'
                                CHECK (shipment_status IN ('created','assigned','in_transit','out_for_delivery','delivered','delayed','cancelled')),
    expected_delivery_date  DATE           NULL,
    created_at              DATETIMEOFFSET NOT NULL DEFAULT SYSDATETIMEOFFSET()
);

-- ============================================================
-- INDEXES
-- ============================================================
CREATE INDEX idx_shipments_status    ON shipments(shipment_status);
CREATE INDEX idx_shipments_warehouse ON shipments(source_warehouse_id);
CREATE INDEX idx_shipments_sender    ON shipments(sender_id);
CREATE INDEX idx_shipments_receiver  ON shipments(receiver_id);
CREATE INDEX idx_shipments_driver    ON shipments(driver_id);
CREATE INDEX idx_drivers_status      ON drivers(status);

-- ============================================================
-- SEED DATA
-- ============================================================

-- Warehouses
SET IDENTITY_INSERT warehouses ON;
INSERT INTO warehouses (id, name, location, max_capacity_kg, current_load_kg) VALUES
(1, 'Cairo Central Hub',    'Cairo',      120000, 0),
(2, 'Giza West Hub',        'Giza',        90000, 0),
(3, 'Alexandria Port Hub',  'Alexandria',  80000, 0),
(4, 'Monufia Delta Hub',    'Monufia',     65000, 0),
(5, 'Dakahlia Nile Hub',    'Dakahlia',    70000, 0);
SET IDENTITY_INSERT warehouses OFF;

-- Drivers
SET IDENTITY_INSERT drivers ON;
INSERT INTO drivers (id, full_name, license_number, phone, status, base_warehouse_id, vehicle_type, shift, work_area) VALUES
(1,  'Gihan Elshamashergy', 'EG-LIC-1001', '01012345678', 'available',   1, 'van',   'morning',   'Cairo'),
(2,  'Ghada Abdelrazik',    'EG-LIC-1002', '01198765432', 'available',   2, 'jumbo', 'evening',   'Giza'),
(3,  'Yasmin Sabry',         'EG-LIC-1003', '01234567890', 'available',   3, 'trila', 'morning',   'Alexandria'),
(4,  'Aya Samaha ',         'EG-LIC-1004', '01556781234', 'off_duty',    4, 'van',   'overnight', 'Monufia'),
(5,  'Hanan Elderiny',        'EG-LIC-1005', '01087654321', 'available',   5, 'jumbo', 'morning',   'Dakahlia'),
(6,  'Eman Elaasy',      'EG-LIC-1006', '01111222333', 'on_delivery', 1, 'trila', 'evening',   'Cairo'),
(7,  'Asmaa Galal',       'EG-LIC-1007', '01299887766', 'available',   2, 'van',   'overnight', 'Giza'),
(8,  'Hodo Elmofty',           'EG-LIC-1008', '01033445566', 'available',   3, 'jumbo', 'morning',   'Alexandria'),
(9,  'Ruby',        'EG-LIC-1009', '01122334455', 'available',   4, 'trila', 'evening',   'Qalyubia'),
(10, 'Hana Elzahed',         'EG-LIC-1010', '01266778899', 'available',   5, 'van',   'morning',   'Suez');
SET IDENTITY_INSERT drivers OFF;

-- Senders
SET IDENTITY_INSERT senders ON;
INSERT INTO senders (id, full_name, area, pickup_shift, phone) VALUES
(1, 'El-Araby Factory',          'Cairo',      'morning',   '01011002233'),
(2, 'Fresh Electric Warehouse',  'Giza',       'evening',   '01133004455'),
(3, 'Alex Steel Factory',        'Alexandria', 'morning',   '01255006677'),
(4, 'Delta Plastics Warehouse',  'Monufia',    'overnight', '01577008899'),
(5, 'Nile Cables Factory',       'Dakahlia',   'evening',   '01022446688');
SET IDENTITY_INSERT senders OFF;

-- Receivers
SET IDENTITY_INSERT receivers ON;
INSERT INTO receivers (id, full_name, area, receive_shift, phone) VALUES
(1, 'Modern Electronics Shop',  'Cairo',      'morning',   '01099112233'),
(2, 'Dokki Appliances Outlet',  'Giza',       'evening',   '01122889977'),
(3, 'Smouha Home Devices Shop', 'Alexandria', 'morning',   '01244556688'),
(4, 'Shebin Retail Outlet',     'Monufia',    'overnight', '01511224466'),
(5, 'Mansoura Tech Shop',       'Dakahlia',   'evening',   '01055667788');
SET IDENTITY_INSERT receivers OFF;

-- Shipments
SET IDENTITY_INSERT shipments ON;
INSERT INTO shipments (
    id, tracking_number, source_warehouse_id, sender_id, receiver_id, driver_id,
    destination_address, receiver_name, receiver_phone,
    weight_kg, distance_km, price_egp, current_location,
    shipment_status, expected_delivery_date
) VALUES
(1,  'EG-20260411-001', 1, 1, 2, 1,  'Giza',       'Dokki Appliances Outlet',  '01122889977', 8.50,  25.00,  153.50, 'Cairo Ring Road',  'in_transit',       DATEADD(day,  2, CAST(GETDATE() AS DATE))),
(2,  'EG-20260411-002', 2, 2, 1, 2,  'Cairo',      'Modern Electronics Shop',  '01099112233', 4.25,  35.00,  179.25, 'Dokki',            'assigned',         DATEADD(day,  1, CAST(GETDATE() AS DATE))),
(3,  'EG-20260410-003', 3, 3, 5, 3,  'Dakahlia',   'Mansoura Tech Shop',       '01055667788', 18.75, 210.00, 718.75, 'Alex Desert Road', 'out_for_delivery', DATEADD(day,  3, CAST(GETDATE() AS DATE))),
(4,  'EG-20260410-004', 4, 4, 4, 4,  'Monufia',    'Shebin Retail Outlet',     '01511224466', 12.00, 15.00,  127.00, 'Shebin El Kom',    'delivered',        DATEADD(day, -1, CAST(GETDATE() AS DATE))),
(5,  'EG-20260409-005', 5, 5, 3, 5,  'Alexandria', 'Smouha Home Devices Shop', '01244556688', 30.40, 180.00, 640.40, 'Mansoura Road',    'delayed',          DATEADD(day,  4, CAST(GETDATE() AS DATE))),
(6,  'EG-20260409-006', 1, 1, 3, 6,  'Alexandria', 'Smouha Home Devices Shop', '01244556688', 7.00,  220.00, 737.00, 'Tanta',            'in_transit',       DATEADD(day,  2, CAST(GETDATE() AS DATE))),
(7,  'EG-20260408-007', 2, 2, 5, 7,  'Dakahlia',   'Mansoura Tech Shop',       '01055667788', 10.00, 120.00, 440.00, 'Banha',            'created',          DATEADD(day,  5, CAST(GETDATE() AS DATE))),
(8,  'EG-20260408-008', 3, 3, 1, 8,  'Cairo',      'Modern Electronics Shop',  '01099112233', 6.30,  220.00, 736.30, 'Wadi El Natrun',   'assigned',         DATEADD(day,  3, CAST(GETDATE() AS DATE))),
(9,  'EG-20260407-009', 4, 4, 2, 9,  'Giza',       'Dokki Appliances Outlet',  '01122889977', 14.80, 95.00,  369.80, 'Sadat City',       'in_transit',       DATEADD(day,  2, CAST(GETDATE() AS DATE))),
(10, 'EG-20260407-010', 5, 5, 4, 10, 'Monufia',    'Shebin Retail Outlet',     '01511224466', 22.00, 90.00,  362.00, 'Quesna',           'out_for_delivery', DATEADD(day,  1, CAST(GETDATE() AS DATE)));
SET IDENTITY_INSERT shipments OFF;
