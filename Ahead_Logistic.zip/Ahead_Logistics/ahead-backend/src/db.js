const sql = require('mssql');
require('dotenv').config();

const config = {
  server: process.env.DB_SERVER || 'localhost',
  port: parseInt(process.env.DB_PORT) || 1433,
  database: process.env.DB_NAME || 'Ahead',
  options: {
    trustServerCertificate: true,
    trustedConnection: process.env.DB_TRUSTED_CONNECTION === 'true',
  },
};

// Only add auth if not using Windows Auth
if (process.env.DB_TRUSTED_CONNECTION !== 'true') {
  config.user = process.env.DB_USER;
  config.password = process.env.DB_PASSWORD;
}

let pool;

async function getPool() {
  if (!pool) {
    pool = await sql.connect(config);
    console.log('Connected to SQL Server:', process.env.DB_NAME);
  }
  return pool;
}

module.exports = { getPool, sql };
