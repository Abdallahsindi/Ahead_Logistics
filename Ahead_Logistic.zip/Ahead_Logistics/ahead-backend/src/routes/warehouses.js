const express = require('express');
const router = express.Router();
const { getPool, sql } = require('../db');

// GET all warehouses
router.get('/', async (req, res) => {
  try {
    const pool = await getPool();
    const result = await pool.request().query('SELECT * FROM warehouses ORDER BY id');
    res.json(result.recordset);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET single warehouse
router.get('/:id', async (req, res) => {
  try {
    const pool = await getPool();
    const result = await pool.request()
      .input('id', sql.BigInt, req.params.id)
      .query('SELECT * FROM warehouses WHERE id = @id');
    if (!result.recordset[0]) return res.status(404).json({ error: 'Warehouse not found' });
    res.json(result.recordset[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST create warehouse
router.post('/', async (req, res) => {
  const { name, location, max_capacity_kg, current_load_kg = 0 } = req.body;
  try {
    const pool = await getPool();
    const result = await pool.request()
      .input('name', sql.NVarChar(255), name)
      .input('location', sql.NVarChar(255), location)
      .input('max_capacity_kg', sql.Numeric(12, 2), max_capacity_kg)
      .input('current_load_kg', sql.Numeric(12, 2), current_load_kg)
      .query(`INSERT INTO warehouses (name, location, max_capacity_kg, current_load_kg)
              OUTPUT INSERTED.*
              VALUES (@name, @location, @max_capacity_kg, @current_load_kg)`);
    res.status(201).json(result.recordset[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PUT update warehouse
router.put('/:id', async (req, res) => {
  const { name, location, max_capacity_kg, current_load_kg } = req.body;
  try {
    const pool = await getPool();
    const result = await pool.request()
      .input('id', sql.BigInt, req.params.id)
      .input('name', sql.NVarChar(255), name)
      .input('location', sql.NVarChar(255), location)
      .input('max_capacity_kg', sql.Numeric(12, 2), max_capacity_kg)
      .input('current_load_kg', sql.Numeric(12, 2), current_load_kg)
      .query(`UPDATE warehouses
              SET name=@name, location=@location, max_capacity_kg=@max_capacity_kg, current_load_kg=@current_load_kg
              OUTPUT INSERTED.*
              WHERE id=@id`);
    if (!result.recordset[0]) return res.status(404).json({ error: 'Warehouse not found' });
    res.json(result.recordset[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE warehouse
router.delete('/:id', async (req, res) => {
  try {
    const pool = await getPool();
    await pool.request()
      .input('id', sql.BigInt, req.params.id)
      .query('DELETE FROM warehouses WHERE id = @id');
    res.json({ message: 'Warehouse deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
