const express = require('express');
const router = express.Router();
const { getPool, sql } = require('../db');

// GET all shipments (with joined names)
router.get('/', async (req, res) => {
  try {
    const pool = await getPool();
    const result = await pool.request().query(`
      SELECT
        s.*,
        w.name  AS warehouse_name,
        sn.full_name AS sender_name,
        r.full_name  AS receiver_full_name,
        d.full_name  AS driver_name
      FROM shipments s
      LEFT JOIN warehouses w  ON s.source_warehouse_id = w.id
      LEFT JOIN senders    sn ON s.sender_id   = sn.id
      LEFT JOIN receivers  r  ON s.receiver_id = r.id
      LEFT JOIN drivers    d  ON s.driver_id   = d.id
      ORDER BY s.created_at DESC
    `);
    res.json(result.recordset);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET single shipment by id or tracking number
router.get('/:identifier', async (req, res) => {
  try {
    const pool = await getPool();
    const id = parseInt(req.params.identifier);
    const isNumeric = !isNaN(id);
    const result = await pool.request()
      .input('id', sql.BigInt, isNumeric ? id : null)
      .input('tracking', sql.NVarChar(100), !isNumeric ? req.params.identifier : null)
      .query(`
        SELECT s.*, w.name AS warehouse_name, sn.full_name AS sender_name,
               r.full_name AS receiver_full_name, d.full_name AS driver_name
        FROM shipments s
        LEFT JOIN warehouses w  ON s.source_warehouse_id = w.id
        LEFT JOIN senders    sn ON s.sender_id   = sn.id
        LEFT JOIN receivers  r  ON s.receiver_id = r.id
        LEFT JOIN drivers    d  ON s.driver_id   = d.id
        WHERE (@id IS NOT NULL AND s.id = @id)
           OR (@tracking IS NOT NULL AND s.tracking_number = @tracking)
      `);
    if (!result.recordset[0]) return res.status(404).json({ error: 'Shipment not found' });
    res.json(result.recordset[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST create shipment
router.post('/', async (req, res) => {
  const {
    tracking_number, source_warehouse_id, sender_id, receiver_id, driver_id,
    destination_address, receiver_name, receiver_phone,
    weight_kg, distance_km, current_location, shipment_status = 'created',
    expected_delivery_date
  } = req.body;

  // Auto-calculate price: 70 + (3 * distance_km) + (1 * weight_kg)
  const price_egp = 70 + (3 * parseFloat(distance_km)) + (1 * parseFloat(weight_kg));

  try {
    const pool = await getPool();
    const result = await pool.request()
      .input('tracking_number', sql.NVarChar(100), tracking_number)
      .input('source_warehouse_id', sql.BigInt, source_warehouse_id)
      .input('sender_id', sql.BigInt, sender_id || null)
      .input('receiver_id', sql.BigInt, receiver_id || null)
      .input('driver_id', sql.BigInt, driver_id || null)
      .input('destination_address', sql.NVarChar(500), destination_address)
      .input('receiver_name', sql.NVarChar(255), receiver_name)
      .input('receiver_phone', sql.NVarChar(50), receiver_phone)
      .input('weight_kg', sql.Numeric(10, 2), weight_kg)
      .input('distance_km', sql.Numeric(10, 2), distance_km)
      .input('price_egp', sql.Numeric(10, 2), price_egp)
      .input('current_location', sql.NVarChar(500), current_location || null)
      .input('shipment_status', sql.NVarChar(20), shipment_status)
      .input('expected_delivery_date', sql.Date, expected_delivery_date || null)
      .query(`INSERT INTO shipments (
                tracking_number, source_warehouse_id, sender_id, receiver_id, driver_id,
                destination_address, receiver_name, receiver_phone,
                weight_kg, distance_km, price_egp, current_location,
                shipment_status, expected_delivery_date
              )
              OUTPUT INSERTED.*
              VALUES (
                @tracking_number, @source_warehouse_id, @sender_id, @receiver_id, @driver_id,
                @destination_address, @receiver_name, @receiver_phone,
                @weight_kg, @distance_km, @price_egp, @current_location,
                @shipment_status, @expected_delivery_date
              )`);
    res.status(201).json(result.recordset[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PATCH update shipment status
router.patch('/:id/status', async (req, res) => {
  const { shipment_status, current_location } = req.body;
  try {
    const pool = await getPool();
    const result = await pool.request()
      .input('id', sql.BigInt, req.params.id)
      .input('shipment_status', sql.NVarChar(20), shipment_status)
      .input('current_location', sql.NVarChar(500), current_location || null)
      .query(`UPDATE shipments
              SET shipment_status=@shipment_status, current_location=@current_location
              OUTPUT INSERTED.*
              WHERE id=@id`);
    if (!result.recordset[0]) return res.status(404).json({ error: 'Shipment not found' });
    res.json(result.recordset[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PUT update shipment
router.put('/:id', async (req, res) => {
  const {
    tracking_number, source_warehouse_id, sender_id, receiver_id, driver_id,
    destination_address, receiver_name, receiver_phone,
    weight_kg, distance_km, price_egp, current_location,
    shipment_status, expected_delivery_date
  } = req.body;
  try {
    const pool = await getPool();
    const result = await pool.request()
      .input('id', sql.BigInt, req.params.id)
      .input('tracking_number', sql.NVarChar(100), tracking_number)
      .input('source_warehouse_id', sql.BigInt, source_warehouse_id)
      .input('sender_id', sql.BigInt, sender_id || null)
      .input('receiver_id', sql.BigInt, receiver_id || null)
      .input('driver_id', sql.BigInt, driver_id || null)
      .input('destination_address', sql.NVarChar(500), destination_address)
      .input('receiver_name', sql.NVarChar(255), receiver_name)
      .input('receiver_phone', sql.NVarChar(50), receiver_phone)
      .input('weight_kg', sql.Numeric(10, 2), weight_kg)
      .input('distance_km', sql.Numeric(10, 2), distance_km)
      .input('price_egp', sql.Numeric(10, 2), price_egp)
      .input('current_location', sql.NVarChar(500), current_location || null)
      .input('shipment_status', sql.NVarChar(20), shipment_status)
      .input('expected_delivery_date', sql.Date, expected_delivery_date || null)
      .query(`UPDATE shipments
              SET tracking_number=@tracking_number, source_warehouse_id=@source_warehouse_id,
                  sender_id=@sender_id, receiver_id=@receiver_id, driver_id=@driver_id,
                  destination_address=@destination_address, receiver_name=@receiver_name,
                  receiver_phone=@receiver_phone, weight_kg=@weight_kg, distance_km=@distance_km,
                  price_egp=@price_egp, current_location=@current_location,
                  shipment_status=@shipment_status, expected_delivery_date=@expected_delivery_date
              OUTPUT INSERTED.*
              WHERE id=@id`);
    if (!result.recordset[0]) return res.status(404).json({ error: 'Shipment not found' });
    res.json(result.recordset[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE shipment
router.delete('/:id', async (req, res) => {
  try {
    const pool = await getPool();
    await pool.request()
      .input('id', sql.BigInt, req.params.id)
      .query('DELETE FROM shipments WHERE id = @id');
    res.json({ message: 'Shipment deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
