const express = require('express');
const router = express.Router();
const { getPool, sql } = require('../db');

// GET all drivers
router.get('/', async (req, res) => {
  try {
    const pool = await getPool();
    const result = await pool.request().query(`
      SELECT d.*, w.name AS warehouse_name
      FROM drivers d
      LEFT JOIN warehouses w ON d.base_warehouse_id = w.id
      ORDER BY d.id
    `);
    res.json(result.recordset);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET single driver
router.get('/:id', async (req, res) => {
  try {
    const pool = await getPool();
    const result = await pool.request()
      .input('id', sql.BigInt, req.params.id)
      .query(`SELECT d.*, w.name AS warehouse_name
              FROM drivers d
              LEFT JOIN warehouses w ON d.base_warehouse_id = w.id
              WHERE d.id = @id`);
    if (!result.recordset[0]) return res.status(404).json({ error: 'Driver not found' });
    res.json(result.recordset[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST create driver
router.post('/', async (req, res) => {
  const { full_name, license_number, phone, status = 'available', base_warehouse_id, vehicle_type, shift, work_area } = req.body;
  try {
    const pool = await getPool();
    const result = await pool.request()
      .input('full_name', sql.NVarChar(255), full_name)
      .input('license_number', sql.NVarChar(100), license_number)
      .input('phone', sql.NVarChar(50), phone)
      .input('status', sql.NVarChar(20), status)
      .input('base_warehouse_id', sql.BigInt, base_warehouse_id || null)
      .input('vehicle_type', sql.NVarChar(10), vehicle_type || null)
      .input('shift', sql.NVarChar(10), shift || null)
      .input('work_area', sql.NVarChar(255), work_area || null)
      .query(`INSERT INTO drivers (full_name, license_number, phone, status, base_warehouse_id, vehicle_type, shift, work_area)
              OUTPUT INSERTED.*
              VALUES (@full_name, @license_number, @phone, @status, @base_warehouse_id, @vehicle_type, @shift, @work_area)`);
    res.status(201).json(result.recordset[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PUT update driver
router.put('/:id', async (req, res) => {
  const { full_name, license_number, phone, status, base_warehouse_id, vehicle_type, shift, work_area } = req.body;
  try {
    const pool = await getPool();
    const result = await pool.request()
      .input('id', sql.BigInt, req.params.id)
      .input('full_name', sql.NVarChar(255), full_name)
      .input('license_number', sql.NVarChar(100), license_number)
      .input('phone', sql.NVarChar(50), phone)
      .input('status', sql.NVarChar(20), status)
      .input('base_warehouse_id', sql.BigInt, base_warehouse_id || null)
      .input('vehicle_type', sql.NVarChar(10), vehicle_type || null)
      .input('shift', sql.NVarChar(10), shift || null)
      .input('work_area', sql.NVarChar(255), work_area || null)
      .query(`UPDATE drivers
              SET full_name=@full_name, license_number=@license_number, phone=@phone,
                  status=@status, base_warehouse_id=@base_warehouse_id, vehicle_type=@vehicle_type,
                  shift=@shift, work_area=@work_area
              OUTPUT INSERTED.*
              WHERE id=@id`);
    if (!result.recordset[0]) return res.status(404).json({ error: 'Driver not found' });
    res.json(result.recordset[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE driver
router.delete('/:id', async (req, res) => {
  try {
    const pool = await getPool();
    await pool.request()
      .input('id', sql.BigInt, req.params.id)
      .query('DELETE FROM drivers WHERE id = @id');
    res.json({ message: 'Driver deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
