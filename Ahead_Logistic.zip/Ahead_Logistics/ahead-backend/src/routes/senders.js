const express = require('express');
const router = express.Router();
const { getPool, sql } = require('../db');

// GET all senders
router.get('/', async (req, res) => {
  try {
    const pool = await getPool();
    const result = await pool.request().query('SELECT * FROM senders ORDER BY id');
    res.json(result.recordset);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET single sender
router.get('/:id', async (req, res) => {
  try {
    const pool = await getPool();
    const result = await pool.request()
      .input('id', sql.BigInt, req.params.id)
      .query('SELECT * FROM senders WHERE id = @id');
    if (!result.recordset[0]) return res.status(404).json({ error: 'Sender not found' });
    res.json(result.recordset[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST create sender
router.post('/', async (req, res) => {
  const { full_name, area, pickup_shift, phone } = req.body;
  try {
    const pool = await getPool();
    const result = await pool.request()
      .input('full_name', sql.NVarChar(255), full_name)
      .input('area', sql.NVarChar(255), area)
      .input('pickup_shift', sql.NVarChar(10), pickup_shift)
      .input('phone', sql.NVarChar(50), phone)
      .query(`INSERT INTO senders (full_name, area, pickup_shift, phone)
              OUTPUT INSERTED.*
              VALUES (@full_name, @area, @pickup_shift, @phone)`);
    res.status(201).json(result.recordset[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PUT update sender
router.put('/:id', async (req, res) => {
  const { full_name, area, pickup_shift, phone } = req.body;
  try {
    const pool = await getPool();
    const result = await pool.request()
      .input('id', sql.BigInt, req.params.id)
      .input('full_name', sql.NVarChar(255), full_name)
      .input('area', sql.NVarChar(255), area)
      .input('pickup_shift', sql.NVarChar(10), pickup_shift)
      .input('phone', sql.NVarChar(50), phone)
      .query(`UPDATE senders
              SET full_name=@full_name, area=@area, pickup_shift=@pickup_shift, phone=@phone
              OUTPUT INSERTED.*
              WHERE id=@id`);
    if (!result.recordset[0]) return res.status(404).json({ error: 'Sender not found' });
    res.json(result.recordset[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE sender
router.delete('/:id', async (req, res) => {
  try {
    const pool = await getPool();
    await pool.request()
      .input('id', sql.BigInt, req.params.id)
      .query('DELETE FROM senders WHERE id = @id');
    res.json({ message: 'Sender deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
