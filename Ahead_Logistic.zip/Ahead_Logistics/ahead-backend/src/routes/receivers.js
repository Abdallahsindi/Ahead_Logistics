const express = require('express');
const router = express.Router();
const { getPool, sql } = require('../db');

// GET all receivers
router.get('/', async (req, res) => {
  try {
    const pool = await getPool();
    const result = await pool.request().query('SELECT * FROM receivers ORDER BY id');
    res.json(result.recordset);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET single receiver
router.get('/:id', async (req, res) => {
  try {
    const pool = await getPool();
    const result = await pool.request()
      .input('id', sql.BigInt, req.params.id)
      .query('SELECT * FROM receivers WHERE id = @id');
    if (!result.recordset[0]) return res.status(404).json({ error: 'Receiver not found' });
    res.json(result.recordset[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST create receiver
router.post('/', async (req, res) => {
  const { full_name, area, receive_shift, phone } = req.body;
  try {
    const pool = await getPool();
    const result = await pool.request()
      .input('full_name', sql.NVarChar(255), full_name)
      .input('area', sql.NVarChar(255), area)
      .input('receive_shift', sql.NVarChar(10), receive_shift)
      .input('phone', sql.NVarChar(50), phone)
      .query(`INSERT INTO receivers (full_name, area, receive_shift, phone)
              OUTPUT INSERTED.*
              VALUES (@full_name, @area, @receive_shift, @phone)`);
    res.status(201).json(result.recordset[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PUT update receiver
router.put('/:id', async (req, res) => {
  const { full_name, area, receive_shift, phone } = req.body;
  try {
    const pool = await getPool();
    const result = await pool.request()
      .input('id', sql.BigInt, req.params.id)
      .input('full_name', sql.NVarChar(255), full_name)
      .input('area', sql.NVarChar(255), area)
      .input('receive_shift', sql.NVarChar(10), receive_shift)
      .input('phone', sql.NVarChar(50), phone)
      .query(`UPDATE receivers
              SET full_name=@full_name, area=@area, receive_shift=@receive_shift, phone=@phone
              OUTPUT INSERTED.*
              WHERE id=@id`);
    if (!result.recordset[0]) return res.status(404).json({ error: 'Receiver not found' });
    res.json(result.recordset[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE receiver
router.delete('/:id', async (req, res) => {
  try {
    const pool = await getPool();
    await pool.request()
      .input('id', sql.BigInt, req.params.id)
      .query('DELETE FROM receivers WHERE id = @id');
    res.json({ message: 'Receiver deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
