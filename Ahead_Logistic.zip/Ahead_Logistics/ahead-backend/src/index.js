require("dotenv").config();
const express = require("express");
const cors = require("cors");
const sql = require("mssql");

const app = express();
app.use(cors());
app.use(express.json());

// ── DB CONFIG ────────────────────────────────────────────────
const dbConfig = {
  server: process.env.DB_SERVER || "localhost",
  port: parseInt(process.env.DB_PORT) || 1433,
  database: process.env.DB_NAME || "Ahead",
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  options: {
    encrypt: false,
    trustServerCertificate: true,
    trustedConnection: process.env.DB_TRUSTED_CONNECTION === "true",
  },
};

let pool;
async function getPool() {
  if (!pool) {
    pool = await sql.connect(dbConfig);
    console.log("✅ Connected to SQL Server");
  }
  return pool;
}

// Helper: wrap response in { data: ... }
const ok = (res, data) => res.json({ data });
const err = (res, error, status = 500) => {
  console.error(error);
  res.status(status).json({ message: error.message || String(error) });
};

// ── SHIPMENTS ────────────────────────────────────────────────

// GET /api/shipments
app.get("/api/shipments", async (req, res) => {
  try {
    const db = await getPool();
    const result = await db.request().query(`
      SELECT
        s.*,
        w.name          AS warehouse_name,
        w.name          AS source_warehouse_name,
        d.full_name     AS driver_name,
        sn.full_name    AS sender_name,
        rc.full_name    AS receiver_full_name,
        s.receiver_name AS receiver_name
      FROM shipments s
      LEFT JOIN warehouses w  ON s.source_warehouse_id = w.id
      LEFT JOIN drivers    d  ON s.driver_id = d.id
      LEFT JOIN senders   sn  ON s.sender_id = sn.id
      LEFT JOIN receivers rc  ON s.receiver_id = rc.id
      ORDER BY s.id DESC
    `);
    ok(res, result.recordset);
  } catch (e) { err(res, e); }
});

// GET /api/shipments/distance-estimate  ← must be BEFORE /:id
app.get("/api/shipments/distance-estimate", async (req, res) => {
  try {
    const { sender_id, receiver_id } = req.query;
    if (!sender_id || !receiver_id) {
      return res.status(400).json({ message: "sender_id and receiver_id are required" });
    }

    const db = await getPool();

    // Distance map between Egyptian governorates (km)
    const distanceMap = {
      "Cairo-Giza": 25,       "Giza-Cairo": 25,
      "Cairo-Alexandria": 220, "Alexandria-Cairo": 220,
      "Cairo-Monufia": 90,    "Monufia-Cairo": 90,
      "Cairo-Dakahlia": 120,  "Dakahlia-Cairo": 120,
      "Giza-Alexandria": 210, "Alexandria-Giza": 210,
      "Giza-Monufia": 95,     "Monufia-Giza": 95,
      "Giza-Dakahlia": 130,   "Dakahlia-Giza": 130,
      "Alexandria-Monufia": 150, "Monufia-Alexandria": 150,
      "Alexandria-Dakahlia": 180, "Dakahlia-Alexandria": 180,
      "Monufia-Dakahlia": 80, "Dakahlia-Monufia": 80,
    };

    const senderRes = await db.request()
      .input("sid", sql.BigInt, sender_id)
      .query("SELECT area FROM senders WHERE id = @sid");

    const receiverRes = await db.request()
      .input("rid", sql.BigInt, receiver_id)
      .query("SELECT area FROM receivers WHERE id = @rid");

    if (!senderRes.recordset[0] || !receiverRes.recordset[0]) {
      return res.status(404).json({ message: "Sender or receiver not found" });
    }

    const senderArea   = senderRes.recordset[0].area;
    const receiverArea = receiverRes.recordset[0].area;
    const key          = `${senderArea}-${receiverArea}`;
    const distance_km  = distanceMap[key] || 100; // fallback 100km

    ok(res, { distance_km, sender_area: senderArea, receiver_area: receiverArea });
  } catch (e) { err(res, e); }
});

// GET /api/shipments/:id
app.get("/api/shipments/:id", async (req, res) => {
  try {
    const db = await getPool();
    const result = await db.request()
      .input("id", sql.BigInt, req.params.id)
      .query(`
        SELECT
          s.*,
          w.name          AS source_warehouse_name,
          d.full_name     AS driver_name,
          sn.full_name    AS sender_name,
          rc.full_name    AS receiver_full_name
        FROM shipments s
        LEFT JOIN warehouses w  ON s.source_warehouse_id = w.id
        LEFT JOIN drivers    d  ON s.driver_id = d.id
        LEFT JOIN senders   sn  ON s.sender_id = sn.id
        LEFT JOIN receivers rc  ON s.receiver_id = rc.id
        WHERE s.id = @id
      `);
    if (!result.recordset[0]) return res.status(404).json({ message: "Shipment not found" });
    ok(res, result.recordset[0]);
  } catch (e) { err(res, e); }
});

// POST /api/shipments
app.post("/api/shipments", async (req, res) => {
  try {
    const db = await getPool();
    const {
      tracking_number, source_warehouse_id, sender_id, receiver_id, driver_id,
      destination_address, receiver_name, receiver_phone,
      weight_kg, distance_km, current_location,
      expected_delivery_date, shipment_status,
    } = req.body;

    // Auto-calc price: 70 + (3 * distance) + (1 * weight)
    const dist  = Number(distance_km) || 100;
    const wt    = Number(weight_kg)   || 1;
    const price = 70 + (3 * dist) + (1 * wt);

    // Auto-generate tracking number if not provided
    const tracking = tracking_number || `EG-${Date.now()}`;

    // Get receiver name from receivers table if not supplied
    let rcvName = receiver_name;
    if (!rcvName && receiver_id) {
      const rcvRes = await db.request()
        .input("rid", sql.BigInt, receiver_id)
        .query("SELECT full_name FROM receivers WHERE id = @rid");
      rcvName = rcvRes.recordset[0]?.full_name || "Unknown";
    }

    const insert = await db.request()
      .input("tracking_number",        sql.NVarChar, tracking)
      .input("source_warehouse_id",    sql.BigInt,   source_warehouse_id)
      .input("sender_id",              sql.BigInt,   sender_id   || null)
      .input("receiver_id",            sql.BigInt,   receiver_id || null)
      .input("driver_id",              sql.BigInt,   driver_id   || null)
      .input("destination_address",    sql.NVarChar, destination_address)
      .input("receiver_name",          sql.NVarChar, rcvName)
      .input("receiver_phone",         sql.NVarChar, receiver_phone)
      .input("weight_kg",              sql.Numeric,  wt)
      .input("distance_km",            sql.Numeric,  dist)
      .input("price_egp",              sql.Numeric,  price)
      .input("current_location",       sql.NVarChar, current_location || null)
      .input("shipment_status",        sql.NVarChar, shipment_status || "created")
      .input("expected_delivery_date", sql.Date,     expected_delivery_date || null)
      .query(`
        INSERT INTO shipments (
          tracking_number, source_warehouse_id, sender_id, receiver_id, driver_id,
          destination_address, receiver_name, receiver_phone,
          weight_kg, distance_km, price_egp, current_location,
          shipment_status, expected_delivery_date
        )
        OUTPUT INSERTED.*
        VALUES (
          @tracking_number, @source_warehouse_id, @sender_id, @receiver_id, @driver_id,
          @destination_address, @receiver_name, @receiver_phone,
          @weight_kg, @distance_km, @price_egp, @current_location,
          @shipment_status, @expected_delivery_date
        )
      `);
    ok(res, insert.recordset[0]);
  } catch (e) { err(res, e); }
});

// PATCH /api/shipments/:id/status
app.patch("/api/shipments/:id/status", async (req, res) => {
  try {
    const db = await getPool();
    const { shipment_status } = req.body;
    const result = await db.request()
      .input("id",     sql.BigInt,   req.params.id)
      .input("status", sql.NVarChar, shipment_status)
      .query(`
        UPDATE shipments SET shipment_status = @status
        OUTPUT INSERTED.*
        WHERE id = @id
      `);
    if (!result.recordset[0]) return res.status(404).json({ message: "Shipment not found" });
    ok(res, result.recordset[0]);
  } catch (e) { err(res, e); }
});

// ── DRIVERS ──────────────────────────────────────────────────

// GET /api/drivers
app.get("/api/drivers", async (req, res) => {
  try {
    const db = await getPool();
    const { status } = req.query;
    const request = db.request();
    let query = "SELECT * FROM drivers";
    if (status) {
      request.input("status", sql.NVarChar, status);
      query += " WHERE status = @status";
    }
    query += " ORDER BY id";
    const result = await request.query(query);
    ok(res, result.recordset);
  } catch (e) { err(res, e); }
});

// POST /api/drivers
app.post("/api/drivers", async (req, res) => {
  try {
    const db = await getPool();
    const { full_name, phone, license_number, vehicle_type, shift, work_area, status } = req.body;
    const result = await db.request()
      .input("full_name",       sql.NVarChar, full_name)
      .input("phone",           sql.NVarChar, phone)
      .input("license_number",  sql.NVarChar, license_number)
      .input("vehicle_type",    sql.NVarChar, vehicle_type  || null)
      .input("shift",           sql.NVarChar, shift         || null)
      .input("work_area",       sql.NVarChar, work_area     || null)
      .input("status",          sql.NVarChar, status        || "available")
      .query(`
        INSERT INTO drivers (full_name, phone, license_number, vehicle_type, shift, work_area, status)
        OUTPUT INSERTED.*
        VALUES (@full_name, @phone, @license_number, @vehicle_type, @shift, @work_area, @status)
      `);
    ok(res, result.recordset[0]);
  } catch (e) { err(res, e); }
});

// ── SENDERS ──────────────────────────────────────────────────

// GET /api/senders/governorates  ← must be BEFORE /api/senders
app.get("/api/senders/governorates", async (req, res) => {
  try {
    // Return fixed list of Egyptian governorates used in the system
    const governorates = [
      "Cairo", "Giza", "Alexandria", "Monufia", "Dakahlia",
      "Qalyubia", "Suez", "Ismailia", "Port Said", "Sharqia",
      "Gharbia", "Kafr El Sheikh", "Beheira", "Fayyum",
      "Beni Suef", "Minya", "Assiut", "Sohag", "Qena",
      "Luxor", "Aswan", "Red Sea", "Matrouh", "New Valley",
      "North Sinai", "South Sinai",
    ];
    ok(res, governorates);
  } catch (e) { err(res, e); }
});

// GET /api/senders
app.get("/api/senders", async (req, res) => {
  try {
    const db = await getPool();
    const result = await db.request().query("SELECT * FROM senders ORDER BY id");
    ok(res, result.recordset);
  } catch (e) { err(res, e); }
});

// POST /api/senders
app.post("/api/senders", async (req, res) => {
  try {
    const db = await getPool();
    const { full_name, area, pickup_shift, phone } = req.body;
    const result = await db.request()
      .input("full_name",    sql.NVarChar, full_name)
      .input("area",         sql.NVarChar, area)
      .input("pickup_shift", sql.NVarChar, pickup_shift)
      .input("phone",        sql.NVarChar, phone)
      .query(`
        INSERT INTO senders (full_name, area, pickup_shift, phone)
        OUTPUT INSERTED.*
        VALUES (@full_name, @area, @pickup_shift, @phone)
      `);
    ok(res, result.recordset[0]);
  } catch (e) { err(res, e); }
});

// ── RECEIVERS ────────────────────────────────────────────────

// GET /api/receivers
app.get("/api/receivers", async (req, res) => {
  try {
    const db = await getPool();
    const result = await db.request().query("SELECT * FROM receivers ORDER BY id");
    ok(res, result.recordset);
  } catch (e) { err(res, e); }
});

// POST /api/receivers
app.post("/api/receivers", async (req, res) => {
  try {
    const db = await getPool();
    const { full_name, area, receive_shift, phone } = req.body;
    const result = await db.request()
      .input("full_name",     sql.NVarChar, full_name)
      .input("area",          sql.NVarChar, area)
      .input("receive_shift", sql.NVarChar, receive_shift)
      .input("phone",         sql.NVarChar, phone)
      .query(`
        INSERT INTO receivers (full_name, area, receive_shift, phone)
        OUTPUT INSERTED.*
        VALUES (@full_name, @area, @receive_shift, @phone)
      `);
    ok(res, result.recordset[0]);
  } catch (e) { err(res, e); }
});

// ── WAREHOUSES ───────────────────────────────────────────────

// GET /api/warehouses
app.get("/api/warehouses", async (req, res) => {
  try {
    const db = await getPool();
    const result = await db.request().query("SELECT * FROM warehouses ORDER BY id");
    ok(res, result.recordset);
  } catch (e) { err(res, e); }
});

// ── ANALYTICS ────────────────────────────────────────────────

// GET /api/analytics/dashboard
app.get("/api/analytics/dashboard", async (req, res) => {
  try {
    const db = await getPool();
    const result = await db.request().query(`
      SELECT
        (SELECT COUNT(*) FROM shipments)                                      AS total_shipments,
        (SELECT COUNT(*) FROM drivers WHERE status = 'available')             AS available_drivers,
        (SELECT COUNT(*) FROM shipments WHERE shipment_status = 'in_transit') AS active_assignments,
        (SELECT COUNT(*) FROM shipments WHERE shipment_status = 'delayed')    AS delayed_events
    `);
    ok(res, result.recordset[0]);
  } catch (e) { err(res, e); }
});

// GET /api/analytics/revenue
app.get("/api/analytics/revenue", async (req, res) => {
  try {
    const db = await getPool();
    const result = await db.request().query(`
      SELECT
        ISNULL(SUM(price_egp), 0) AS total_egp,
        ISNULL(SUM(CASE WHEN CAST(created_at AS DATE) = CAST(GETDATE() AS DATE)
                        THEN price_egp ELSE 0 END), 0) AS today_egp,
        ISNULL(SUM(CASE WHEN created_at >= DATEADD(day, -7, GETDATE())
                        THEN price_egp ELSE 0 END), 0) AS week_egp
      FROM shipments
      WHERE shipment_status != 'cancelled'
    `);
    ok(res, result.recordset[0]);
  } catch (e) { err(res, e); }
});

// GET /api/analytics/routes
app.get("/api/analytics/routes", async (req, res) => {
  try {
    const db   = await getPool();
    const range = req.query.range || "month";

    const daysMap = { day: 1, week: 7, month: 30 };
    const days    = daysMap[range] || 30;

    const result = await db.request()
      .input("days", sql.Int, days)
      .query(`
        SELECT
          destination_address,
          COUNT(*) AS shipments_count,
          SUM(price_egp) AS total_revenue
        FROM shipments
        WHERE created_at >= DATEADD(day, -@days, GETDATE())
          AND shipment_status != 'cancelled'
        GROUP BY destination_address
        ORDER BY shipments_count DESC
      `);
    ok(res, result.recordset);
  } catch (e) { err(res, e); }
});

// ── START ─────────────────────────────────────────────────────
const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`🚀 Ahead Logistics API running on http://localhost:${PORT}`);
});
